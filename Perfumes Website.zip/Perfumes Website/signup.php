<?php 

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$confirmpassword = $_POST['confirmpassword'];


$conn = new mysqli('locslhost', 'root', 'signup');
if($conn->connect_error)
{
die('Connnection Failed : '.$conn->connect_error);
}
else
{
	$stmt = $ conn->prepare("insert into registeration(username, email, password, confirmpassword) 
		values(?,?,?,?)");
	$stmt->bind_param("ssss", $username, $email, $password, $confirmpassword);
	$stmt->execute();
	echo "Signup Successfully ...";
	$stmt->close();
	$conn->close();
}

 ?>